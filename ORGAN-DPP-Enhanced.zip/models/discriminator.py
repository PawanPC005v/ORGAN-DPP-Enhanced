import torch
import torch.nn as nn
import torch.nn.functional as F

class Discriminator(nn.Module):
    def __init__(self, vocab_size=64, embed_dim=128, hidden_dim=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.conv = nn.Conv1d(embed_dim, hidden_dim, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        # x: (batch, seq_len)
        emb = self.embedding(x).permute(0,2,1)  # (batch, embed, seq)
        h = F.relu(self.conv(emb))
        h = self.pool(h).squeeze(-1)
        out = torch.sigmoid(self.fc(h))
        return out
