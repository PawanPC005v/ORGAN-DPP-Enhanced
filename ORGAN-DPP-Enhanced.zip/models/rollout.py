# Minimal rollout for policy-gradient style reward estimation
import torch
import torch.nn.functional as F

class Rollout:
    def __init__(self, generator, update_rate=0.8):
        self.gen = generator
        self.ema = None
        self.update_rate = update_rate

    def get_reward(self, partial_seqs, num_rollouts=4, max_len=80, reward_fn=None):
        # partial_seqs: Tensor(batch, cur_len)
        device = next(self.gen.parameters()).device
        batch = partial_seqs.size(0)
        rewards = torch.zeros(batch, device=device)
        for _ in range(num_rollouts):
            # naive: sample completion from generator
            samples = self.gen.sample(batch_size=batch, max_len=max_len)
            if reward_fn is not None:
                r = reward_fn(samples)
                rewards += r
        rewards = rewards / float(num_rollouts)
        return rewards

    def update_params(self):
        # placeholder for EMA update
        pass
