import torch
import torch.nn as nn
import torch.nn.functional as F

class TemperatureControlledGenerator(nn.Module):
    def __init__(self, vocab_size=64, embed_dim=128, hidden_dim=256, num_layers=1, device='cpu'):
        super().__init__()
        self.device = device
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, num_layers=num_layers, batch_first=True)
        self.output = nn.Linear(hidden_dim, vocab_size)
        self.vocab_size = vocab_size
        self.temperature = 1.0

    def forward(self, x, hidden=None):
        # x: (batch, seq_len)
        emb = self.embedding(x)
        out, hidden = self.lstm(emb, hidden)
        logits = self.output(out)  # (batch, seq_len, vocab)
        return logits, hidden

    def sample(self, batch_size=8, max_len=80, temperature=None, start_token=0, end_token=1):
        if temperature is None:
            temperature = self.temperature
        self.eval()
        device = next(self.parameters()).device
        seqs = torch.zeros((batch_size, max_len), dtype=torch.long, device=device)
        inp = torch.full((batch_size,1), start_token, dtype=torch.long, device=device)
        hidden = None
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)
        for t in range(max_len):
            logits, hidden = self.forward(inp, hidden)
            logits = logits[:, -1, :] / (temperature + 1e-8)
            probs = F.softmax(logits, dim=-1)
            nxt = torch.multinomial(probs, num_samples=1).squeeze(-1)
            seqs[:, t] = nxt
            inp = nxt.unsqueeze(1)
            finished = finished | (nxt == end_token)
            if finished.all():
                break
        return seqs
