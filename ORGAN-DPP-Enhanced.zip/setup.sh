#!/usr/bin/env bash
python -m venv organ_env
source organ_env/bin/activate
pip install -r requirements.txt
echo "Virtualenv created and dependencies installed (in activated shell)."
