import numpy as np

class CurriculumScheduler:
    def __init__(self, stages):
        self.stages = stages
        self.cumulative = np.cumsum([s['epochs'] for s in stages])

    def get_config(self, epoch):
        idx = int(np.searchsorted(self.cumulative, epoch))
        if idx >= len(self.stages):
            idx = len(self.stages) - 1
        stage = self.stages[idx]
        # smooth temperature if in transition
        if idx > 0:
            prev_epoch = self.cumulative[idx-1]
            progress = (epoch - prev_epoch) / float(stage['epochs'])
            prev_temp = self.stages[idx-1]['temp']
            temp = prev_temp + (stage['temp'] - prev_temp) * self._smooth(progress)
        else:
            temp = stage['temp']
        return {
            'rewards': stage['rewards'],
            'temperature': float(temp),
            'diversity_weight': stage.get('diversity_weight', 0.1),
            'stage_idx': idx
        }

    def _smooth(self, x):
        x = max(0.0, min(1.0, x))
        return 1.0 / (1.0 + np.exp(-10*(x - 0.5)))
