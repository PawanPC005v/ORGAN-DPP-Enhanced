import matplotlib.pyplot as plt
import os
def plot_metrics(history, out_dir='outputs'):
    os.makedirs(out_dir, exist_ok=True)
    for k,v in history.items():
        plt.figure()
        plt.plot(v)
        plt.title(k)
        plt.savefig(os.path.join(out_dir, f'{k}.png'))
        plt.close()
