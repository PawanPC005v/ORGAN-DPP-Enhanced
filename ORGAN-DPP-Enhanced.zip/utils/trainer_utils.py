import torch
def clip_grad(model, max_norm=5.0):
    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)

def linear_anneal(start, end, step, total_steps):
    frac = min(1.0, float(step)/float(total_steps))
    return start + (end - start) * frac
