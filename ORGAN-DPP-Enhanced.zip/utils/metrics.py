import numpy as np
try:
    from rdkit import Chem
    from rdkit.Chem import QED, AllChem, Descriptors
    RDKit_AVAILABLE = True
except Exception:
    RDKit_AVAILABLE = False

class MolecularMetrics:
    def __init__(self):
        pass

    def validity(self, smiles_list):
        if not RDKit_AVAILABLE:
            # naive: treat non-empty as valid
            return [1 if s and len(s)>2 else 0 for s in smiles_list]
        vals = []
        for s in smiles_list:
            mol = Chem.MolFromSmiles(s)
            vals.append(1 if mol is not None else 0)
        return vals

    def qed(self, smiles_list):
        if not RDKit_AVAILABLE:
            return [0.0 for _ in smiles_list]
        out = []
        for s in smiles_list:
            mol = Chem.MolFromSmiles(s)
            if mol is None:
                out.append(0.0)
            else:
                out.append(QED.qed(mol))
        return out

    def novelty(self, smiles_list, reference_set):
        ref = set(reference_set)
        return [1 if s not in ref else 0 for s in smiles_list]
