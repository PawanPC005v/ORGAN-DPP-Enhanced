import wandb
def init(project='organ-dpp'):
    try:
        wandb.init(project=project)
        return True
    except Exception:
        return False
