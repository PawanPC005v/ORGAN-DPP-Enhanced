import json
def load_vocab(path):
    with open(path,'r') as f:
        return json.load(f)

def simple_tokenize(smiles, max_len=80):
    # character-level tokenization (toy)
    toks = list(smiles)[:max_len]
    return toks
