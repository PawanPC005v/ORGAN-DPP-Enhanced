import numpy as np
from scipy.linalg import eigh
from sklearn.preprocessing import normalize

class FeatureBasedDPP:
    def __init__(self, rank=64):
        self.rank = rank

    def _get_features(self, items):
        # items: list of SMILES or embeddings
        # If items are numpy arrays already, assume embeddings
        if isinstance(items, np.ndarray):
            return items
        raise ValueError("Provide precomputed embeddings as numpy array.")

    def sample(self, features, k=32):
        # features: (n, d)
        features = np.array(features, dtype=float)
        n, d = features.shape
        # normalize
        features = normalize(features, axis=1)
        # low-rank SVD-like via eigh on dxd if d < n
        if d < n:
            gram_small = features.T.dot(features)
            eigvals, eigvecs_small = eigh(gram_small)
            # keep positive
            mask = eigvals > 1e-8
            eigvals = eigvals[mask]
            eigvecs_small = eigvecs_small[:, mask]
            eigvecs = features.dot(eigvecs_small)
        else:
            gram = features.dot(features.T)
            eigvals, eigvecs = eigh(gram)
            mask = eigvals > 1e-8
            eigvals = eigvals[mask]
            eigvecs = eigvecs[:, mask]
        if len(eigvals) == 0:
            # fallback: greedy by norm
            norms = np.linalg.norm(features, axis=1)
            inds = np.argsort(-norms)[:k]
            return inds.tolist()
        # simple probabilistic selection proportional to eigenvalues
        probs = eigvals / (eigvals + 1)
        selected_eig = np.random.rand(len(probs)) < probs
        if not selected_eig.any():
            # greedy fallback
            norms = np.linalg.norm(features, axis=1)
            return np.argsort(-norms)[:k].tolist()
        V = eigvecs[:, selected_eig]
        selected = []
        for _ in range(min(k, V.shape[1])):
            probs = (V**2).sum(axis=1)
            probs = probs / probs.sum()
            idx = np.random.choice(len(probs), p=probs)
            selected.append(int(idx))
            # project out
            vi = V[idx:idx+1, :].copy()
            V = V - (V.dot(vi.T) / (vi.dot(vi.T) + 1e-8)) * vi
        # pad if needed
        if len(selected) < k:
            rem = [i for i in range(n) if i not in selected]
            selected += rem[:(k - len(selected))]
        return selected
