import os
def load_smiles(path, max_samples=None):
    with open(path, 'r', encoding='utf-8') as f:
        lines = [l.strip() for l in f if l.strip()]
    if max_samples:
        lines = lines[:max_samples]
    return lines
