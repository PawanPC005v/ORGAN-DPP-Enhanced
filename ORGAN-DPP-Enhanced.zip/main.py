import argparse, json, os
from utils.data_loader import load_smiles
from models.generator import TemperatureControlledGenerator
from models.discriminator import Discriminator
from utils.curriculum import CurriculumScheduler
from utils.dpp import FeatureBasedDPP

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/curriculum_dpp.json")
    parser.add_argument("--data", default="data/example_smiles.txt")
    args = parser.parse_args()
    cfg = json.load(open(args.config))
    smiles = load_smiles(args.data)
    print(f"Loaded {len(smiles)} examples")
    curriculum = CurriculumScheduler(cfg['curriculum_stages'])
    gen = TemperatureControlledGenerator(vocab_size=cfg['vocab_size'], embed_dim=cfg['embed_dim'], hidden_dim=cfg['hidden_dim'])
    dpp = FeatureBasedDPP(rank=cfg.get('dpp_rank',64))
    total_epochs = sum([s['epochs'] for s in cfg['curriculum_stages']])
    for epoch in range(total_epochs):
        conf = curriculum.get_config(epoch)
        gen.temperature = conf['temperature']
        samples = gen.sample(batch_size=8, max_len=cfg['max_len'])
        print(f"Epoch {epoch}: temp={conf['temperature']:.2f} sample[0]:", samples[0].tolist())
    print('Done demo run.')

if __name__ == '__main__':
    main()
