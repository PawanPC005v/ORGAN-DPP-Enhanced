import argparse
from utils.data_loader import load_smiles
from utils.metrics import MolecularMetrics

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/example_smiles.txt")
    args = parser.parse_args()
    smiles = load_smiles(args.data)
    metrics = MolecularMetrics()
    val = metrics.validity(smiles)
    print("Validity fraction:", sum(val)/len(val))

if __name__ == '__main__':
    main()
