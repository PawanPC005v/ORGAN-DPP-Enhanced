from utils.visualizer import plot_metrics
def main():
    history = {'validity':[0.1,0.5,0.8,0.9], 'qed':[0.2,0.3,0.4,0.45]}
    plot_metrics(history)
    print("Saved plots to outputs/")
if __name__ == '__main__':
    main()
