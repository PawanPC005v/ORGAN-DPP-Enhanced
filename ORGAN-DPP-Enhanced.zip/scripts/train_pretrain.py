import argparse
import torch
from models.generator import TemperatureControlledGenerator
from utils.data_loader import load_smiles

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    args = parser.parse_args()
    smiles = load_smiles(args.data, max_samples=100)
    print("Loaded", len(smiles), "molecules")
    # placeholder: would convert to tokens and train with MLE
    gen = TemperatureControlledGenerator()
    samples = gen.sample(batch_size=4, max_len=50)
    print("Sampled sequences:", samples)

if __name__ == '__main__':
    main()
