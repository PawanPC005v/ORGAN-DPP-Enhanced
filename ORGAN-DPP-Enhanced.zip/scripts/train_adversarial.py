import argparse
import torch
import json
from utils.data_loader import load_smiles
from models.generator import TemperatureControlledGenerator
from models.discriminator import Discriminator
from utils.curriculum import CurriculumScheduler
from utils.dpp import FeatureBasedDPP
from utils.metrics import MolecularMetrics

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/curriculum_dpp.json")
    parser.add_argument("--data", default="data/example_smiles.txt")
    args = parser.parse_args()
    cfg = json.load(open(args.config))
    smiles = load_smiles(args.data, max_samples=200)
    print("Loaded", len(smiles), "molecules")
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    gen = TemperatureControlledGenerator(vocab_size=cfg['vocab_size'], embed_dim=cfg['embed_dim'], hidden_dim=cfg['hidden_dim']).to(device)
    dis = Discriminator(vocab_size=cfg['vocab_size']).to(device)
    curriculum = CurriculumScheduler(cfg['curriculum_stages'])
    dpp = FeatureBasedDPP(rank=cfg.get('dpp_rank',64))
    metrics = MolecularMetrics()
    # Toy loop: demonstrate curriculum and DPP usage
    for epoch in range(sum([s['epochs'] for s in cfg['curriculum_stages']])):
        conf = curriculum.get_config(epoch)
        gen.temperature = conf['temperature']
        samples = gen.sample(batch_size=64, max_len=cfg['max_len'])
        # convert samples to fake "embeddings" by random vectors for demo
        import numpy as np
        emb = np.random.randn(samples.shape[0], cfg.get('dpp_rank',64))
        inds = dpp.sample(emb, k=min(cfg.get('dpp_select_size',32), len(emb)))
        print(f"Epoch {epoch}: stage {conf['stage_idx']} temp={conf['temperature']:.2f} selected {len(inds)}")
    print("Demo finished.")

if __name__ == '__main__':
    main()
