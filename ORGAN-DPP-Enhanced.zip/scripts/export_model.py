import torch
from models.generator import TemperatureControlledGenerator
def main():
    gen = TemperatureControlledGenerator()
    torch.save(gen.state_dict(), 'outputs/generator.pt')
    print('Saved outputs/generator.pt')
if __name__ == '__main__':
    main()
