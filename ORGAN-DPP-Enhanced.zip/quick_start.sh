#!/usr/bin/env bash
python main.py --config configs/curriculum_dpp.json --data data/example_smiles.txt
