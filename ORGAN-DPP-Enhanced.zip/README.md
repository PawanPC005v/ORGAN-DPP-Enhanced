# ORGAN-DPP-Enhanced

Objective-Reinforced Generative Adversarial Network with Feature-Based DPP,
Curriculum Learning and Temperature Annealing — minimal runnable skeleton.

This repository provides a lightweight, runnable prototype for experimentation
and extension. It includes:
- Temperature-controlled LSTM generator
- Simple discriminator
- Feature-based (embedding) DPP sampler (low-rank / greedy fallback)
- Curriculum scheduler and temperature annealing
- Minimal training scripts that run on small toy data

Run (after installing requirements):
```bash
python main.py --config configs/curriculum_dpp.json
```

This distribution is intentionally small — replace components with production-ready
implementations for large-scale experiments.
